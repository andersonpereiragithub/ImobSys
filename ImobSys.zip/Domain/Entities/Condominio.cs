﻿using System;

namespace ImobSys.Domain.Entities
{
    public class Condominio
    {
        public string? NomeCondominio { get; set; }
        public decimal Valor { get; set; }
    }
}
