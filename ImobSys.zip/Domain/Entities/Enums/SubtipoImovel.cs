﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ImobSys.Domain.Entities.Enums
{
    public enum SubtipoImovel
    {
        Casa,
        Sala,
        Loja,
        Galpao,
        Terreno,
        Garagem,
        Apartamento,
        Granja
    }
}
