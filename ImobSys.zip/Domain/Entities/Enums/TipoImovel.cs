﻿using System;

namespace ImobSys.Domain.Entities.Enums
{
    public enum TipoImovel
    {
        Comercial,
        Residencial,
        Misto
    }
}
