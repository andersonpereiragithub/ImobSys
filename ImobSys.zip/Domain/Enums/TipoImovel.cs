﻿using System;

namespace ImobSys.Domain.Enums
{
    public enum TipoImovel
    {
        Comercial,
        Residencial,
        Misto
    }
}
