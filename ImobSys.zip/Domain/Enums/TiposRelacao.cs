﻿using ImobSys.Domain.Entities.Clientes;

namespace ImobSys.Domain.Enums
{
    public enum TiposRelacao
    {
        Locador,
        Locatario,
        Fiador
    }
}
