﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ImobSys.Domain.Enums
{
    public enum SubtipoImovel
    {
        Apto,
        Casa,
        Galpao,
        Garagem,
        Granja,
        Loja,
        Sala,
        Terreno
    }
}
